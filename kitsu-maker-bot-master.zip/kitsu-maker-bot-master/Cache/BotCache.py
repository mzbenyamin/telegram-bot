# coding=utf-8

# Copyright (c) 2017 Kaikyu

bots = {}
join_keys = {}
